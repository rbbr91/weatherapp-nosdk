package com.br.weatherapp.presenter;

import com.br.weatherapp.model.City;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CityInteractorImpl implements CityInteractor {

    public void getCities(final OnFinishedListener fListener, double latitude, double longitude) {

        String APP_ID = "ae2eaf5534348ee21b8fd9eb4ca94950";
        CityApiFactory.getCityClient().getCities(latitude, longitude, APP_ID)
                .enqueue(new Callback<ArrayList<City>>() {
                    @Override
                    public void onResponse(Call<ArrayList<City>> call, Response<ArrayList<City>> response) {
                        ArrayList<City> result = response.body();
                        if (result != null) {
                            fListener.onCityReady(result);
                        }
                    }

                    @Override
                    public void onFailure(Call<ArrayList<City>> call, Throwable t) {
                        try {
                            throw new InterruptedException("Error occured!");
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } finally {

                        }
                    }
                });
    }


}
