package com.br.weatherapp.view;

import com.br.weatherapp.model.City;
import java.util.ArrayList;

public interface ICityView {
    void setItems(ArrayList<City> items);
}
