package com.br.weatherapp.presenter;

import com.br.weatherapp.model.City;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.Call;

import java.util.ArrayList;

public interface CityApiInterface {
    @GET("/find")
    Call<ArrayList<City> > getCities(@Query("lat") double latitude, @Query("lon") double longitude, @Query("APPID") String appId);
}
