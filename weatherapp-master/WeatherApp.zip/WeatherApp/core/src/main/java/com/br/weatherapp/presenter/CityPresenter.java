package com.br.weatherapp.presenter;

public interface CityPresenter {
    void onSearchStarted(double latitude, double longitude);
}
